<?php

namespace Drupal\custom_pm\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\Core\Url;
use Drupal\taxonomy\Entity\Term;

/**
 * Provides a 'SliderBlock' block.
 *
 * @Block(
 *  id = "slider_block",
 *  admin_label = @Translation("Slider block"),
 * )
 */
class SliderBlock extends BlockBase {

 /**
   * {@inheritdoc}
   */
 public function getDataBuild(){

 	$default_langcode = \Drupal::languageManager()->getCurrentLanguage()->getId();
 	$node_ids = \Drupal::entityQuery('node')
 	->condition('type', 'slideshow')
 	->condition('langcode',$default_langcode,'=')
 	->condition('status', 1)
 	->sort('created' , 'DESC')
 	->range(0, 3)
 	->execute();

 	$items_data = [];
 	$nodes =  \Drupal\node\Entity\Node::loadMultiple($node_ids);
 	foreach ($nodes as $node) {
 		$node = $node->getTranslation($default_langcode);
 		$body = $node->hasField('body') ? \Drupal\Component\Utility\Unicode::truncate(preg_replace('/[^\w$\x{0080}-\x{FFFF}]+/u', ' ',strip_tags($node->get('body')->value) ), 280, true, true) : '';
 		$body = str_replace("nbsp", "", $body);
 		$items_data[] = array(
 			"id" => $node->id(),
 			"title" => $node->get('title')->value,
 			"link" => $node->get('field_url'),	
 			"image" => $node->get('field_image')->entity->uri->value,
 			"ownerid" => $node->getOwnerId(),
 			"ownername"=> \Drupal\user\Entity\User::load($node->getOwnerId())->getDisplayName(),
 			"creatednode" => $node->getCreatedTime(),
 			"desc" => $body,
 		);

 	}
 	$node_ids = \Drupal::entityQuery('node')
 	->condition('type', 'front_boxes')
 	->condition('langcode',$default_langcode,'=')
 	->condition('status', 1)
 	->condition('promote', 1)
 	->sort('field_order' , 'ASC')
 	->sort('created' , 'DESC')
 	->range(0, 4)
 	->execute();

 	$boxes = [];
 	$nodes =  \Drupal\node\Entity\Node::loadMultiple($node_ids);
 	foreach ($nodes as $node) {
 		$node = $node->getTranslation($default_langcode);
 		$body = $node->hasField('field_description') ? \Drupal\Component\Utility\Unicode::truncate(preg_replace('/[^\w$\x{0080}-\x{FFFF}]+/u', ' ',strip_tags($node->get('field_description')->value) ), 110, true, true) : '';
 		$body = str_replace("nbsp", "", $body);
 		$boxes[] = array(
 			"id" => $node->id(),
 			"title" => $node->get('title')->value,
 			"link" => $node->get('field_url'),	
 			"icon" => $node->get('field_icon')->entity->uri->value,
      "is_public" => ($node->hasField('field_is_public') && !$node->get('field_is_public')->isEmpty())?(bool)$node->get('field_is_public')->first()->getString():false,
 			"body" => $body,
 		);
 	}
 	return array(
		 'sliders' => $items_data,
		 'boxes' => $boxes,
		);
 }

 public function build() {
 	return array(
 		'#theme' => 'slider_block',
 		'#items' => $this->getDataBuild(),
 		'#cache' => [
 			'tags' => ['node_list'],
 		],

 	);
 }

}
